package com.TourismAgencySystem.Model;

public class Admin extends User {
    public Admin(int id, String name, String username, String password, String type) {
        super(id, name, username, password, type);
    }
    public Admin() {
    }

}
